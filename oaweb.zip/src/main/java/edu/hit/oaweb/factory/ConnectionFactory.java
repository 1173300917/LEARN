package edu.hit.oaweb.factory;

import java.sql.Connection;
import java.sql.DriverManager;

//辅助连接工厂类
public class ConnectionFactory {
	public static Connection getConnection() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/oa?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false","root","root");
		
	}
}
