package edu.hit.oaweb.test;

import java.util.List;

import edu.hit.oaweb.hr.dao.IDepartmentDao;
import edu.hit.oaweb.hr.factory.DaoFactory;
import edu.hit.oaweb.hr.factory.ServiceFactory;
import edu.hit.oaweb.hr.model.DepartmentModel;
import edu.hit.oaweb.hr.service.IDepartmentService;

public class Test {

	public static void main(String[] args) {
		try {
			IDepartmentService service = ServiceFactory.createDepartmentService();
			
			List<DepartmentModel> list=service.selectAll();
			for(DepartmentModel dm01:list) {
				System.out.println(dm01.getName());
			}
			System.out.println("OK");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
