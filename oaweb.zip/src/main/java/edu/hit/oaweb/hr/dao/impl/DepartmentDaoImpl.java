package edu.hit.oaweb.hr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import edu.hit.oaweb.factory.ConnectionFactory;
import edu.hit.oaweb.hr.dao.IDepartmentDao;
import edu.hit.oaweb.hr.model.DepartmentModel;

public class DepartmentDaoImpl implements IDepartmentDao {

	@Override
	public void insert(DepartmentModel dm) throws Exception {
		String sql = "insert into oa_department (DEPTCODE,DEPTNAME) values (?,?)";
		Connection cn = ConnectionFactory.getConnection();
		PreparedStatement ps = cn.prepareStatement(sql);
		ps.setString(1, dm.getCode());
		ps.setString(2, dm.getName());
		ps.executeUpdate();
		ps.close();
		cn.close();
		
	}

	@Override
	public void update(DepartmentModel dm) throws Exception {
		String sql = "update oa_department set DEPTCODE=?,DEPTNAME=? where DEPTNO=?";
		Connection cn = ConnectionFactory.getConnection();
		PreparedStatement ps = cn.prepareStatement(sql);
		ps.setString(1, dm.getCode());
		ps.setString(2, dm.getName());
		ps.setInt(3, dm.getNo());
		ps.executeUpdate();
		ps.close();
		cn.close();

	}

	@Override
	public void delete(DepartmentModel dm) throws Exception {
		String sql = "delete from oa_department where where DEPTNO=?";
		Connection cn = ConnectionFactory.getConnection();
		PreparedStatement ps = cn.prepareStatement(sql);
		ps.setInt(1, dm.getNo());
		ps.executeUpdate();
		ps.close();
		cn.close();

	}

	@Override
	public List<DepartmentModel> selectAll() throws Exception {
		List<DepartmentModel> list = new ArrayList<DepartmentModel>();
		String sql = "select *  from oa_department";
		Connection cn = ConnectionFactory.getConnection();
		PreparedStatement ps = cn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			DepartmentModel dm = new DepartmentModel();
			dm.setNo(rs.getInt("DEPTNO"));
			dm.setCode(rs.getString("DEPTCODE"));
			dm.setName(rs.getString("DEPTNAME"));
			list.add(dm);
		}
		rs.close();
		ps.close();
		cn.close();
		return list;
	}

	@Override
	public DepartmentModel selectByNo(int no) throws Exception {
		DepartmentModel dm =null;
		String sql = "select *  from oa_department where DEPTNO=?";
		Connection cn = ConnectionFactory.getConnection();
		PreparedStatement ps = cn.prepareStatement(sql);
		ps.setInt(1, no);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			dm = new DepartmentModel();
			dm.setNo(rs.getInt("DEPTNO"));
			dm.setCode(rs.getString("DEPTCODE"));
			dm.setName(rs.getString("DEPTNAME"));
		}
		rs.close();
		ps.close();
		cn.close();
		return dm;
	}

}
