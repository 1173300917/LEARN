package edu.hit.oaweb.hr.factory;

import edu.hit.oaweb.hr.service.IDepartmentService;
import edu.hit.oaweb.hr.service.impl.DepartmentServiceImpl;

public class ServiceFactory {
	
	//部门
	public static IDepartmentService createDepartmentService() throws Exception{
		return new DepartmentServiceImpl();
	}

}
