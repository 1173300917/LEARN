package edu.hit.oaweb.hr.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.hit.oaweb.hr.factory.ServiceFactory;
import edu.hit.oaweb.hr.model.DepartmentModel;
import edu.hit.oaweb.hr.service.IDepartmentService;

/**
 * Servlet implementation class DepartmentDeleteController
 */
@WebServlet("/department/delete.do")
public class DepartmentDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//取得表单提交的数据
		String sno=request.getParameter("no");
		
		//验证数据
		
		//类型转换
		int no=Integer.parseInt(sno);
		//准备Model对象
		DepartmentModel dm=new DepartmentModel();
		dm.setNo(no);
		
		try {
			//创建业务对象
			IDepartmentService departmentService=ServiceFactory.createDepartmentService();
			//调业务对象方法
			departmentService.delete(dm);
			//跳转到List的前分发控制器
			response.sendRedirect("tolist.do");
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
			response.sendRedirect("../error/error.jsp?message="+e.getLocalizedMessage());
		}
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
