package edu.hit.oaweb.hr.service;

import java.util.List;

import edu.hit.oaweb.hr.model.DepartmentModel;

public interface IDepartmentService {
	
	public void add(DepartmentModel dm) throws Exception;
	public void modify(DepartmentModel dm) throws Exception;
	public void delete(DepartmentModel dm) throws Exception;
	
	//查询
	public List<DepartmentModel> selectAll() throws Exception;
	public DepartmentModel selectByNo(int no) throws Exception;
	
}
