package edu.hit.oaweb.hr.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.hit.oaweb.hr.factory.ServiceFactory;
import edu.hit.oaweb.hr.model.DepartmentModel;
import edu.hit.oaweb.hr.service.IDepartmentService;

/**
 * 部门的列表页面的前分发控制器类
 */
@WebServlet("/department/tolist.do")
public class DepartmentToListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try {
			IDepartmentService departmentService=ServiceFactory.createDepartmentService();
			List<DepartmentModel> departmentList=departmentService.selectAll();
			//保存给JSP显示的数据
			request.setAttribute("departmentList", departmentList);
			//跳转到list.jsp
			//response.sendRedirect("list.jsp");
			request.getRequestDispatcher("list.jsp").forward(request, response);
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
