package edu.hit.oaweb.hr.factory;

import edu.hit.oaweb.hr.dao.IDepartmentDao;
import edu.hit.oaweb.hr.dao.impl.DepartmentDaoImpl;

//hr模块的工厂
public class DaoFactory {
	
	//创建部门Dao接口的对象
	public static IDepartmentDao createDepartmentDao() throws Exception{
		return new DepartmentDaoImpl();
	}
	
}
