package edu.hit.oaweb.hr.dao;

import java.util.List;

import edu.hit.oaweb.hr.model.DepartmentModel;

public interface IDepartmentDao {
	
	public void insert(DepartmentModel dm) throws Exception;
	public void update(DepartmentModel dm) throws Exception;
	public void delete(DepartmentModel dm) throws Exception;
	
	//查询
	public List<DepartmentModel> selectAll() throws Exception;
	public DepartmentModel selectByNo(int no) throws Exception;

}
