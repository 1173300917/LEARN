package edu.hit.oaweb.hr.service.impl;

import java.util.ArrayList;
import java.util.List;

import edu.hit.oaweb.hr.dao.IDepartmentDao;
import edu.hit.oaweb.hr.factory.DaoFactory;
import edu.hit.oaweb.hr.model.DepartmentModel;
import edu.hit.oaweb.hr.service.IDepartmentService;

public class DepartmentServiceImpl implements IDepartmentService {
	
	private IDepartmentDao dao = null;
	
	public DepartmentServiceImpl() {
		try {
			dao = DaoFactory.createDepartmentDao();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void add(DepartmentModel dm) throws Exception {
		dao.insert(dm);

	}

	@Override
	public void modify(DepartmentModel dm) throws Exception {
		dao.update(dm);

	}

	@Override
	public void delete(DepartmentModel dm) throws Exception {
		dao.delete(dm);

	}

	@Override
	public List<DepartmentModel> selectAll() throws Exception {
		List<DepartmentModel> list = new ArrayList<DepartmentModel>();
		list = dao.selectAll();
		return list;
	}

	@Override
	public DepartmentModel selectByNo(int no) throws Exception {
		DepartmentModel dm = dao.selectByNo(no);
		return dm;
	}

}
