package edu.hit.oaweb.hr.model;

import java.io.Serializable;

//部门类
public class DepartmentModel implements Serializable {
	private int no = 0;
	private String code = null;
	private String name = null;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
