package edu.hit.oaweb.admin.factory;

import edu.hit.oaweb.admin.dao.IUserDao;
import edu.hit.oaweb.admin.dao.impl.UserDaoImpl;
//ADMIN模块DAO工厂
public class DaoFactory {
	
	public static IUserDao createUserDao()
	{
		return new UserDaoImpl();
	}

}
