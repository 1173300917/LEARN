package edu.hit.oaweb.admin.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import edu.hit.oaweb.admin.dao.IUserDao;
import edu.hit.oaweb.admin.model.UserModel;
import edu.hit.oaweb.factory.ConnectionFactory;
import edu.hit.oaweb.hr.model.DepartmentModel;

//管理员DAO实现类
public class UserDaoImpl implements IUserDao {

	@Override
	public void update(UserModel um) throws Exception {
		String sql="update oa_adminuser set UPASSWORD=?,USERNAME=? where USERID=?";
		Connection cn=ConnectionFactory.getConnection();
		
		PreparedStatement ps=cn.prepareStatement(sql);
		ps.setString(1,um.getPassword());
		ps.setString(2,um.getName());
		ps.setString(3, um.getId());
		ps.executeUpdate();
		ps.close();
		
		cn.close();
		
	}
	
	@Override
	public UserModel getById(String id) throws Exception {
		
		UserModel um=null;
		String sql="select * from oa_adminuser where USERID=?";
		Connection cn=ConnectionFactory.getConnection();
		PreparedStatement ps=cn.prepareStatement(sql);
		ps.setString(1,id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			um=new UserModel();
			um.setId(rs.getString("USERID"));
			um.setPassword(rs.getString("UPASSWORD"));
			um.setName(rs.getString("USERNAME"));
		}
		rs.close();
		ps.close();
		cn.close();
		return um;
	}

	

}
