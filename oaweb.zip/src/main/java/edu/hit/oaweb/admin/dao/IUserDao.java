package edu.hit.oaweb.admin.dao;

import edu.hit.oaweb.admin.model.UserModel;

//管理员DAO层接口
public interface IUserDao {
	public void update(UserModel um) throws Exception;
	//通过ID取得管理员对象
	public UserModel getById(String id) throws Exception;

}
