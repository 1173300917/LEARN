package edu.hit.oaweb.admin.service.impl;

import edu.hit.oaweb.admin.dao.IUserDao;
import edu.hit.oaweb.admin.factory.DaoFactory;
import edu.hit.oaweb.admin.model.UserModel;
import edu.hit.oaweb.admin.service.IUserService;
//管理员的业务层实现类
public class UserServiceImpl implements IUserService {
	
	

	@Override
	public UserModel getById(String id) throws Exception {
		
		return DaoFactory.createUserDao().getById(id);
	}

	@Override
	public boolean validate(String id, String password) throws Exception {
		
		UserModel um=DaoFactory.createUserDao().getById(id);
		if(um!=null&&um.getPassword()!=null&&um.getPassword().equals(password)) {
			return true;
		}
		else {
			return false;
		}
		
	}
	//修改密码方法
	@Override
	public void changePassword(String id, String password) throws Exception {
		IUserDao userdao=DaoFactory.createUserDao();
		UserModel um=userdao.getById(id);
		um.setPassword(password);
		userdao.update(um);
		

	}

}
