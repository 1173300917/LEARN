package edu.hit.oaweb.admin.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.hit.oaweb.admin.factory.ServiceFactory;
import edu.hit.oaweb.admin.model.UserModel;
import edu.hit.oaweb.admin.service.IUserService;

/**
 * 管理员用户登录处理Controller
 */
@WebServlet("/userlogin.do")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//取得提交的数据
		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		//创建管理员的业务对象
		IUserService userService=ServiceFactory.createUserService();
		try {

			if(userService.validate(userid, password)) {
				UserModel um=userService.getById(userid);
				HttpSession session=request.getSession();
				session.setAttribute("user", um);
				response.sendRedirect("home/tohome.do");
			}
			else {
				response.sendRedirect("login.jsp");
				
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
