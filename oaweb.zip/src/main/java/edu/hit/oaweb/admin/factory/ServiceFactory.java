package edu.hit.oaweb.admin.factory;

import edu.hit.oaweb.admin.service.IUserService;
import edu.hit.oaweb.admin.service.impl.UserServiceImpl;

//Service业务层工厂类
public class ServiceFactory {
	
	public static IUserService createUserService() {
		return new UserServiceImpl();
	}

}
